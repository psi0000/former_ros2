// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_BASE__MESSAGE_TYPE_HPP_
#define ROAS_BASE__MESSAGE_TYPE_HPP_

#include <string>
#include <vector>
#include <array>

using namespace std;

struct RobotState
{
  /// The state of the emergency stop switch on the motor controller
  bool emergency_stop = false;

  /// The voltage from the main battery (V)
  double battery_voltage = 0.0;

  /// The voltage from the charger (V)
  double charging_voltage = 0.0;

  /// The current from the 12V user power (A)
  double user_12v_current = 0.0;

  /// The current from the 24V user power (A)
  double user_24v_current = 0.0;
};

struct MotorState
{
  /// The actual position by the encoder value (rad)
  array<double, 2> position = { 0.0, 0.0 };

  /// The actual velocity measured by the encoder as the actual RPM value (rad/s)
  array<double, 2> velocity = { 0.0, 0.0 };

  /// The current flowing through the motors (A)
  array<double, 2> current = { 0.0, 0.0 };

  /// Internal temperature of the motor controller (C)
  double temperature = 0.0;

  /// The state of the controller fault conditions
  vector<string> fault_flags = { "Not connected" };
};

struct Feedback
{
  string robot;

  /// Robot state
  RobotState robot_state;

  /// Motor state
  vector<MotorState> motor_state;
};

struct Command
{
  vector<double> command;
};

#endif  // ROAS_BASE__MESSAGE_TYPE_HPP_