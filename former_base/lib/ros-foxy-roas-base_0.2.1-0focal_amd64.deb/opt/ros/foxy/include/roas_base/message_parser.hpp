// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_BASE__MESSAGE_PARSER_HPP_
#define ROAS_BASE__MESSAGE_PARSER_HPP_

#include <string>
#include <vector>
#include <bitset>
#include <chrono>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"

#include "roas_base/message_type.hpp"

using namespace std;

class MessageParser
{
public:
  MessageParser(Feedback& feedback, std_msgs::msg::Bool& estop_state, size_t num_channels);

  virtual ~MessageParser() = default;

  /**
   * \brief Parse the message
   * \param msg Message read through serial communication
   */
  void parse(const string& msg);

  /**
   * \brief Parse the error message
   * \param index Index of the controller
   * \param flags Number converted to binary number
   */
  void faultFlags(const uint8_t index, const uint16_t flags);

  /**
   * \brief Convert RPM to angular velocity
   * \param rpm Motor's RPM
   */
  double toVelocity(const double rpm);

  /**
   * \brief Convert encoder count to radian
   * \param enc Motor's encoder count
   */
  double toRad(const double enc);

  /// Feedback related
  Feedback& feedback_;

  // Estop state
  std_msgs::msg::Bool& estop_state_;

  /// Number of channels
  size_t num_channels_;

  /// CPR(count per revolution) of the motor
  uint32_t cpr_;

  /// For debugging
  chrono::system_clock::time_point last_time_;
  int16_t max_latency_;

private:
};

#endif  // ROAS_BASE__MESSAGE_PARSER_HPP_