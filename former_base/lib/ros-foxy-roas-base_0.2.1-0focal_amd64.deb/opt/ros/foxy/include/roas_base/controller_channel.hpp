/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef ROAS_BASE__CONTROLLER_CHANNEL_HPP_
#define ROAS_BASE__CONTROLLER_CHANNEL_HPP_

#include <string>
#include <iostream>
#include <vector>
#include <thread>

#include "roas_serial/serial.h"

using namespace std;

class ControllerChannel
{
public:
  /**
   * @brief DriverChannel
   * @param serial           Reference variable of sericl class
   * @param index_controller Index of the controller
   */
  ControllerChannel(shared_ptr<serial::Serial>& serial, const size_t controller_index);

  virtual ~ControllerChannel() = default;

  /**
   * \brief Send the message about the velocity command
   * \param channel Controller's channel (1: Left, 2: Right)
   * \param rpm     RPM to be sent by command
   */
  void writeVelocity(const uint8_t channel, const int32_t rpm);

  /**
   * \brief Send the message about the velocity command
   * \param channel Controller's channel
   * \param count   Count
   */
  void writePosition(const uint8_t channel, const int32_t count);

  /**
   * \brief Stop the motor
   * \param channel Controller's channel
   */
  void stopMotor(const uint8_t channel);

  /**
   * \brief Reset the encoder counter
   */
  void resetEncCount();

  /**
   * \brief Set the controller's control mode
   * \param channel Controller's channel (1: Left, 2: Right)
   * \param mode    Control mode (0: Open-loop, 1: Closed-loop speed, 2: Closed-loop position relative)
   */
  void setOperationMode(const uint8_t channel, const uint8_t mode);

  /**
   * \brief Reset the encoder counter
   * \param channel Controller's channel (1: Left, 2: Right)
   * \param counter Target counter
   */
  void setEncCounter(const uint8_t channel, const int32_t counter);

private:
  shared_ptr<serial::Serial>& serial_;

  size_t index_;
};

#endif  // ROAS_BASE__CONTROLLER_CHANNEL_HPP_