// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_BASE__ROAS_CONTROLLER_HPP_
#define ROAS_BASE__ROAS_CONTROLLER_HPP_

#include <string>
#include <vector>
#include <cmath>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"

#include "roas_serial/serial.h"
#include "roas_base/message_parser.hpp"
#include "roas_base/controller_channel.hpp"

using namespace std;

class RoasController
{
public:
  RoasController(const shared_ptr<rclcpp::Node>& node, string robot, size_t joints_size, double wheel_radius,
                 double max_speed, double max_rpm, string port, int32_t baud, Feedback& feedback,
                 std_msgs::msg::Bool& estop_state);

  virtual ~RoasController();

  /**
   * \brief Initialize
   */
  bool init();

  /**
   * \brief Initial setting for serial communication
   */
  bool connect();

  /**
   * \brief Read message
   */
  void read();

  /**
   * \brief Reset the encoder counter
   */
  bool resetEncCount();

  /**
   * \brief Send the velocity command
   * \param msg Velocity command message for each motors (rad)
   */
  void sendCommand(const Command& cmd);

  /**
   * \brief Limit to below maximum speed
   * \param speed Angular velocity to send
   * \return If it is faster than the maximum speed, the maximum speed returns
   */
  double limitMaxSpeed(const double speed);

  /**
   * \brief Convert angular velocity to RPM
   * \param w Angular velocity
   * \return RPM value
   */
  double toRPM(const double w);

  /**
   * \brief Set the emergency stop
   * \param command emergency stop command
   */
  void setEstop(bool command);

  /**
   * \brief Send the hearbeat data
   */
  void sendHearbeat();

  /**
   * \brief Stop MicroBasicScript Operation
   */
  void stopScript();

  /**
   * \brief Start MicroBasicScript Operation
   */
  void startScript();

  /**
   * \brief Restart MicroBasicScript Operation
   */
  void restartScript();

  /// Class for serial communication
  shared_ptr<serial::Serial> serial_;

private:
  /// ROS2 parameters
  std::shared_ptr<rclcpp::Node> node_;

  /// Robot name
  string robot_;

  /// Robot parameters
  double wheel_radius_, max_speed_, max_rpm_;

  /// Class for parsing the message
  shared_ptr<MessageParser> parser_;

  /// Serial parameters
  string port_;
  int32_t baud_;

  /// Class for communication interfaces on each controller
  vector<ControllerChannel> channel_;
};

#endif  // ROAS_BASE__ROAS_CONTROLLER_HPP_