// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_BASE__ROAS_GPIO_HPP_
#define ROAS_BASE__ROAS_GPIO_HPP_

#include <string>
#include <chrono>
#include <thread>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "rclcpp/rclcpp.hpp"
#include "roas_serial/serial.h"
#include "realtime_tools/realtime_publisher.h"
#include "std_msgs/msg/bool.hpp"
#include "sensor_msgs/msg/range.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

using namespace std;

class RoasGPIO : public rclcpp::Node
{
public:
  RoasGPIO(const string& node);

  virtual ~RoasGPIO();

  /**
   * \brief Initialize
   */
  void init();

  /**
   * \brief Initial setting for serial communication
   */
  bool connect();

  /**
   * \brief Read message
   */
  void read();

  /**
   * \brief Parse the message
   * \param msg Message read through serial communication
   */
  void parse(const string& msg);

  /**
   * \brief Set the led color and mode
   * \param color Color
   * \param mode Mode
   */
  bool setLed(const uint8_t color, const uint8_t mode);

  /**
   * \brief Publish the ultrasonic sensor data
   */
  void publish();

private:
  /// ROS2 parameters
  vector<rclcpp::Publisher<sensor_msgs::msg::Range>::SharedPtr> pub_ultrasonic_;
  vector<rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr> pub_scan_;
  vector<rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr> pub_digital_io_;

  vector<shared_ptr<realtime_tools::RealtimePublisher<sensor_msgs::msg::Range>>> rp_ultrasonic_;
  vector<shared_ptr<realtime_tools::RealtimePublisher<sensor_msgs::msg::LaserScan>>> rp_scan_;
  vector<shared_ptr<realtime_tools::RealtimePublisher<std_msgs::msg::Bool>>> rp_digital_io_;

  // Timer for publisher
  rclcpp::TimerBase::SharedPtr publish_timer_;

  /// Serial parameters
  string port_;
  int32_t baud_;
  shared_ptr<serial::Serial> serial_;

  /// Ultrasonic sensor frame id
  vector<string> ultrasonic_frame_;

  /// For converting range to scan
  bool convert_range_to_scan_;
  size_t angle_resolution_;

  /// Digital IO topic name
  vector<string> digital_io_topic_;

  /// LED control
  string led_color_;
  string led_mode_;

  /// Publish rate
  int publish_rate_;
};

#endif  // ROAS_BASE__ROAS_GPIO_HPP_