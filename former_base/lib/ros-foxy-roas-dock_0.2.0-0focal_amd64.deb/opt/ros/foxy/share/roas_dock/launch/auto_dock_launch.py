#!/usr/bin/env python3

# Author: Brighten Lee

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    return LaunchDescription(
        [
            Node(
                package="roas_dock",
                executable="auto_dock_node",
                name="auto_dock_node",
                output="screen",
                parameters=[
                    {
                        "timeout": 60.0,
                        "recovery_distance": 0.3,
                        "max_detection_diatance": 2.0,
                        "docking_offset": 0.252,
                        "detection_accuracy": 0.8,
                        "free_diatance": 0.1,
                        "undock_distance": 0.3,
                    }
                ],
            ),
        ]
    )
