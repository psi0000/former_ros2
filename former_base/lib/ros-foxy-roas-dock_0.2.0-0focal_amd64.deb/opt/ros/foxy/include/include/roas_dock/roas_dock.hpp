// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_DOCK__ROAS_DOCK_HPP_
#define ROAS_DOCK__ROAS_DOCK_HPP_

#include <chrono>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "realtime_tools/realtime_publisher.h"
#include "std_msgs/msg/bool.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

#include "roas_dock/detection.hpp"
#include "roas_dock/diff_controller.hpp"
#include "roas_dock/action/dock.hpp"
#include "roas_dock/action/undock.hpp"

using namespace std;

class RoasDock
{
public:
  using DockGoalHandle = rclcpp_action::ServerGoalHandle<roas_dock::action::Dock>;
  using UndockGoalHandle = rclcpp_action::ServerGoalHandle<roas_dock::action::Undock>;
  using DockFeedback = roas_dock::action::Dock::Feedback;
  using UndockFeedback = roas_dock::action::Undock::Feedback;
  using DockResult = roas_dock::action::Dock::Result;
  using UndockResult = roas_dock::action::Undock::Result;

  RoasDock(const std::string& node);

  virtual ~RoasDock() = default;

  /**
   * \brief Execute the docking aciton server
   * \param goal_handle Docking goal handler
   */
  void dockCallback(shared_ptr<DockGoalHandle> goal_handle);

  /**
   * \brief Execute the undocking aciton server
   * \param goal_handle Unocking goal handler
   */
  void undockCallback(shared_ptr<UndockGoalHandle> goal_handle);

  /**
   * \brief LaserScan callback
   * \param msg Lidar sensor data
   */
  void scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr& msg);

  /**
   * \brief Docking signal callback
   * \param msg Docking signal
   */
  void dockedCallback(const std_msgs::msg::Bool::SharedPtr& msg);

  /**
   * \brief Check to see the docking status
   * \param goal_handle Unocking goal handler
   * \return Success or not
   */
  bool checkDockStatus(shared_ptr<DockGoalHandle>& goal_handle);

  /**
   * \brief Check to see the undocking status
   * \param goal_handle Unocking goal handler
   * \return Success or not
   */
  bool checkUndockStatus(shared_ptr<UndockGoalHandle>& goal_handle);

  /**
   * \brief Reset flag values related to docking status
   */
  void resetFlags();

  /**
   * \brief Check to see the timeout
   * \return Timeout or not
   */
  bool isTimeout();

  shared_ptr<rclcpp::Node> node_;

private:
  /// Process for detecting docking station
  shared_ptr<Detection> detection_;

  /// Process for differential controller
  shared_ptr<DiffController> controller_;

  /// ROS2 parameters
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr sub_scan_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr sub_docked_;

  rclcpp::CallbackGroup::SharedPtr callback_group_{ nullptr };

  /// Action server for docking and undocking
  rclcpp_action::Server<roas_dock::action::Dock>::SharedPtr dock_server_;
  rclcpp_action::Server<roas_dock::action::Undock>::SharedPtr undock_server_;
  shared_ptr<DockGoalHandle> dock_goal_handle_;
  shared_ptr<UndockGoalHandle> undock_goal_handle_;

  /// Control loop rate;
  rclcpp::WallRate rate_;

  /// Flag related to docking state
  bool docked_, charging_, cancel_;

  /// For check to see the timeout
  chrono::steady_clock::time_point time_stamp_;
  double timeout_sec_;

  /// Parameters for undocking
  double undock_distance_;  // Distance the robot moves to undock [m]
  double undock_heading_;   // Heading the robot rotates to undock [rad]

  /// Parameters for recovery
  double recovery_distance_;  // Distance for recovery [m]
};

#endif  // ROAS_DOCK__ROAS_DOCK_HPP_