// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_DOCK__AVERAGE_FILTER_H_
#define ROAS_DOCK__AVERAGE_FILTER_H_

using namespace std;

class AverageFilter
{
public:
  /**
   * \brief Average Filter
   */
  AverageFilter()
  {
    clear();
  }

  virtual ~AverageFilter() = default;

  /**
   * \brief Add a new data and calculate the cumulative average
   * \param data New input data
   */
  double add(const double data)
  {
    length_ += 1;
    old_weight_ = (static_cast<double>(length_) - 1.0) / static_cast<double>(length_);
    new_weight_ = 1.0 / static_cast<double>(length_);
    average_ = average_ * old_weight_ + data * new_weight_;
    return average_;
  }

  /**
   * \brief Clearing
   */
  void clear()
  {
    average_ = 0.0;
    length_ = 0;
    old_weight_ = 0.0;
    new_weight_ = 0.0;
  }

  /**
   * \brief Return the average data
   */
  double get()
  {
    return average_;
  }

private:
  /// Average of input data
  double average_;

  /// Length of input data list
  size_t length_;

  /// Weight of the previois average and new input data
  double old_weight_, new_weight_;
};

#endif  // ROAS_DOCK__AVERAGE_FILTER_H_