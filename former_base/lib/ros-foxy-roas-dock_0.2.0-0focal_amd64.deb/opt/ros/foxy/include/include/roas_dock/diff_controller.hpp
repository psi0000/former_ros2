// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_DOCK__DIFF_CONTROLLER_HPP_
#define ROAS_DOCK__DIFF_CONTROLLER_HPP_

#include <string>
#include <vector>
#include <cmath>
#include <angles/angles.h>

#include "rclcpp/rclcpp.hpp"
#include "tf2/transform_datatypes.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "realtime_tools/realtime_publisher.h"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "nav_msgs/msg/path.hpp"

using namespace std;

class DiffController
{
public:
  /**
   * \brief Constructor for differential controller
   * This controller is implemented by referring to the following paper.
   * "A Smooth Control Law for Graceful Motion of
   *  Differential Wheeled Mobile Robots in 2D Environment"
   * by Jong Jin Park and Benjamin Kuipers, ICRA 2011
   */
  DiffController(const shared_ptr<rclcpp::Node>& node);

  virtual ~DiffController() = default;

  /**
   * \brief Behavior for the robot to dock
   * \param target Target pose
   */
  bool dock(const geometry_msgs::msg::PoseStamped& target);

  /**
   * \brief Behavior for the robot to undock
   * \param target_distance Target distance [m]
   * \param target_heading Target heading (yaw) [rad]
   */
  bool undock(const double target_distance, const double target_heading);

  /**
   * \brief Send the stop command and reset the flags
   */
  void stop();

  /**
   * \brief Publish the velocity commmand
   */
  void publishCommand();

  /**
   * \brief Publish the velocity commmand
   * \param command Twist message
   */
  void publishPath();

private:
  /// ROS2 parameters
  shared_ptr<rclcpp::Node> node_;

  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_cmd_vel_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr pub_path_;
  shared_ptr<realtime_tools::RealtimePublisher<geometry_msgs::msg::Twist>> rp_cmd_vel_;
  shared_ptr<realtime_tools::RealtimePublisher<nav_msgs::msg::Path>> rp_path_;

  unique_ptr<tf2_ros::Buffer> tf_buffer_;
  shared_ptr<tf2_ros::TransformListener> tf_listener_;

  /// Parameters for smooth control
  double k1_;           // Ratio of the rate of change in theta to the rate of change in r
  double k2_;           // Higher value of the vehicle converge to the slow manifold more quickly
  double beta_;         // Higher value of beta let the velocity drop more quickly as k increases
  double lambda_;       // Higher value of lambda results in more sharply peaked curve
  double min_linear_;   // Minimum linear velocity of robot
  double max_linear_;   // Maximum linear velocity of robot
  double min_angular_;  // Minimum angular velocity of robot
  double max_angular_;  // Maximum angular velocity of robot

  /// Offset to prevent angular velocity bounce when close to the target
  double offset_;

  /// Starting position of the undocking behavior
  geometry_msgs::msg::PoseStamped starting_pose_;

  /// Flags for the undocking behavior
  bool running_, turning_;
};

#endif  // ROAS_DOCK__DIFF_CONTROLLER_HPP_