// Copyright (c) 2021, ROAS Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef ROAS_DOCK__DETECTION_HPP_
#define ROAS_DOCK__DETECTION_HPP_

#include <string>
#include <vector>
#include <mutex>
#include <cmath>
#include <angles/angles.h>
#include <boost/shared_ptr.hpp>

#include "rclcpp/rclcpp.hpp"
#include "tf2/transform_datatypes.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "tf2_ros/transform_broadcaster.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

#include "roas_dock/average_filter.h"

using namespace std;

class Detection
{
public:
  Detection(const shared_ptr<rclcpp::Node>& node);

  virtual ~Detection() = default;

  /**
   * \brief Initialize the values to initiate detection
   */
  void start();

  /**
   * \brief Stop the detection behavior
   */
  void stop();

  /**
   * \brief Get the target pose
   * \param target_pose Target pose
   * \return Whether or not got the target pose after detecting the docking station
   */
  bool getTargetPose(geometry_msgs::msg::PoseStamped& target);

  /**
   * \brief Execute detection behavior
   * \param scan LaserScan data
   */
  void detect(const sensor_msgs::msg::LaserScan::SharedPtr& scan);

  /**
   * \brief Check to see if docking station is detected
   * \return Whether docking station was detected or not
   */
  bool isDetected()
  {
    return detected_;
  }

  /**
   * \brief Extract vertex from LaserScan data
   * \param scan LaserScan data
   * \param index Index of LaserScan data
   */
  bool extractVertex(const sensor_msgs::msg::LaserScan::SharedPtr& scan, const size_t index);

private:
  mutex mutex_;

  /// ROS2 parameters
  shared_ptr<rclcpp::Node> node_;

  unique_ptr<tf2_ros::Buffer> tf_buffer_;
  shared_ptr<tf2_ros::TransformListener> tf_listener_;
  unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;

  /// Pose variables
  geometry_msgs::msg::PoseStamped starting_pose_;
  geometry_msgs::msg::PoseStamped vertex_pose_;
  geometry_msgs::msg::PoseStamped dock_pose_;

  /// Average filter
  AverageFilter avg_x_;
  AverageFilter avg_y_;
  AverageFilter avg_yaw_;

  /// Progress variables
  bool running_, detected_, init_;

  /// Frame that tracks the robot pose
  string tracking_frame_;

  /// Maximum detection distance
  double max_diatance_;

  /// Offset between vertex and contact point
  double docking_offset_;

  /// Accuracy to detect target
  double detection_accuracy_;

  /// Index of the detection range
  size_t angle_min_idx_, angle_max_idx_;

  /// Difference from the front direction
  double diff_front_;
};

#endif  // ROAS_DOCK__DETECTION_HPP_