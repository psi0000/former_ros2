// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from roas_dock:action/Dock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DETAIL__DOCK__BUILDER_HPP_
#define ROAS_DOCK__ACTION__DETAIL__DOCK__BUILDER_HPP_

#include "roas_dock/action/detail/dock__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_Goal_dock
{
public:
  Init_Dock_Goal_dock()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::roas_dock::action::Dock_Goal dock(::roas_dock::action::Dock_Goal::_dock_type arg)
  {
    msg_.dock = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_Goal>()
{
  return roas_dock::action::builder::Init_Dock_Goal_dock();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_Result_docked
{
public:
  Init_Dock_Result_docked()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::roas_dock::action::Dock_Result docked(::roas_dock::action::Dock_Result::_docked_type arg)
  {
    msg_.docked = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_Result>()
{
  return roas_dock::action::builder::Init_Dock_Result_docked();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_Feedback_pose
{
public:
  Init_Dock_Feedback_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::roas_dock::action::Dock_Feedback pose(::roas_dock::action::Dock_Feedback::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_Feedback>()
{
  return roas_dock::action::builder::Init_Dock_Feedback_pose();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_SendGoal_Request_goal
{
public:
  explicit Init_Dock_SendGoal_Request_goal(::roas_dock::action::Dock_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::roas_dock::action::Dock_SendGoal_Request goal(::roas_dock::action::Dock_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_SendGoal_Request msg_;
};

class Init_Dock_SendGoal_Request_goal_id
{
public:
  Init_Dock_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Dock_SendGoal_Request_goal goal_id(::roas_dock::action::Dock_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_Dock_SendGoal_Request_goal(msg_);
  }

private:
  ::roas_dock::action::Dock_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_SendGoal_Request>()
{
  return roas_dock::action::builder::Init_Dock_SendGoal_Request_goal_id();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_SendGoal_Response_stamp
{
public:
  explicit Init_Dock_SendGoal_Response_stamp(::roas_dock::action::Dock_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::roas_dock::action::Dock_SendGoal_Response stamp(::roas_dock::action::Dock_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_SendGoal_Response msg_;
};

class Init_Dock_SendGoal_Response_accepted
{
public:
  Init_Dock_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Dock_SendGoal_Response_stamp accepted(::roas_dock::action::Dock_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_Dock_SendGoal_Response_stamp(msg_);
  }

private:
  ::roas_dock::action::Dock_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_SendGoal_Response>()
{
  return roas_dock::action::builder::Init_Dock_SendGoal_Response_accepted();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_GetResult_Request_goal_id
{
public:
  Init_Dock_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::roas_dock::action::Dock_GetResult_Request goal_id(::roas_dock::action::Dock_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_GetResult_Request>()
{
  return roas_dock::action::builder::Init_Dock_GetResult_Request_goal_id();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_GetResult_Response_result
{
public:
  explicit Init_Dock_GetResult_Response_result(::roas_dock::action::Dock_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::roas_dock::action::Dock_GetResult_Response result(::roas_dock::action::Dock_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_GetResult_Response msg_;
};

class Init_Dock_GetResult_Response_status
{
public:
  Init_Dock_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Dock_GetResult_Response_result status(::roas_dock::action::Dock_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_Dock_GetResult_Response_result(msg_);
  }

private:
  ::roas_dock::action::Dock_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_GetResult_Response>()
{
  return roas_dock::action::builder::Init_Dock_GetResult_Response_status();
}

}  // namespace roas_dock


namespace roas_dock
{

namespace action
{

namespace builder
{

class Init_Dock_FeedbackMessage_feedback
{
public:
  explicit Init_Dock_FeedbackMessage_feedback(::roas_dock::action::Dock_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::roas_dock::action::Dock_FeedbackMessage feedback(::roas_dock::action::Dock_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::roas_dock::action::Dock_FeedbackMessage msg_;
};

class Init_Dock_FeedbackMessage_goal_id
{
public:
  Init_Dock_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Dock_FeedbackMessage_feedback goal_id(::roas_dock::action::Dock_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_Dock_FeedbackMessage_feedback(msg_);
  }

private:
  ::roas_dock::action::Dock_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::roas_dock::action::Dock_FeedbackMessage>()
{
  return roas_dock::action::builder::Init_Dock_FeedbackMessage_goal_id();
}

}  // namespace roas_dock

#endif  // ROAS_DOCK__ACTION__DETAIL__DOCK__BUILDER_HPP_
