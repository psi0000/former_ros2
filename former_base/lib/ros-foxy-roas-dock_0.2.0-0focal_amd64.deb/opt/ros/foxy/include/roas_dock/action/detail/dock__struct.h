// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from roas_dock:action/Dock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DETAIL__DOCK__STRUCT_H_
#define ROAS_DOCK__ACTION__DETAIL__DOCK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_Goal
{
  bool dock;
} roas_dock__action__Dock_Goal;

// Struct for a sequence of roas_dock__action__Dock_Goal.
typedef struct roas_dock__action__Dock_Goal__Sequence
{
  roas_dock__action__Dock_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_Goal__Sequence;


// Constants defined in the message

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_Result
{
  bool docked;
} roas_dock__action__Dock_Result;

// Struct for a sequence of roas_dock__action__Dock_Result.
typedef struct roas_dock__action__Dock_Result__Sequence
{
  roas_dock__action__Dock_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose_stamped__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_Feedback
{
  geometry_msgs__msg__PoseStamped pose;
} roas_dock__action__Dock_Feedback;

// Struct for a sequence of roas_dock__action__Dock_Feedback.
typedef struct roas_dock__action__Dock_Feedback__Sequence
{
  roas_dock__action__Dock_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "roas_dock/action/detail/dock__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  roas_dock__action__Dock_Goal goal;
} roas_dock__action__Dock_SendGoal_Request;

// Struct for a sequence of roas_dock__action__Dock_SendGoal_Request.
typedef struct roas_dock__action__Dock_SendGoal_Request__Sequence
{
  roas_dock__action__Dock_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} roas_dock__action__Dock_SendGoal_Response;

// Struct for a sequence of roas_dock__action__Dock_SendGoal_Response.
typedef struct roas_dock__action__Dock_SendGoal_Response__Sequence
{
  roas_dock__action__Dock_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} roas_dock__action__Dock_GetResult_Request;

// Struct for a sequence of roas_dock__action__Dock_GetResult_Request.
typedef struct roas_dock__action__Dock_GetResult_Request__Sequence
{
  roas_dock__action__Dock_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "roas_dock/action/detail/dock__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_GetResult_Response
{
  int8_t status;
  roas_dock__action__Dock_Result result;
} roas_dock__action__Dock_GetResult_Response;

// Struct for a sequence of roas_dock__action__Dock_GetResult_Response.
typedef struct roas_dock__action__Dock_GetResult_Response__Sequence
{
  roas_dock__action__Dock_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "roas_dock/action/detail/dock__struct.h"

// Struct defined in action/Dock in the package roas_dock.
typedef struct roas_dock__action__Dock_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  roas_dock__action__Dock_Feedback feedback;
} roas_dock__action__Dock_FeedbackMessage;

// Struct for a sequence of roas_dock__action__Dock_FeedbackMessage.
typedef struct roas_dock__action__Dock_FeedbackMessage__Sequence
{
  roas_dock__action__Dock_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Dock_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROAS_DOCK__ACTION__DETAIL__DOCK__STRUCT_H_
