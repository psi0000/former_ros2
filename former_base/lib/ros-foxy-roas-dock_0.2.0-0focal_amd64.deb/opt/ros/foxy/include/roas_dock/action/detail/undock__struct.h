// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from roas_dock:action/Undock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DETAIL__UNDOCK__STRUCT_H_
#define ROAS_DOCK__ACTION__DETAIL__UNDOCK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_Goal
{
  bool undock;
} roas_dock__action__Undock_Goal;

// Struct for a sequence of roas_dock__action__Undock_Goal.
typedef struct roas_dock__action__Undock_Goal__Sequence
{
  roas_dock__action__Undock_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_Goal__Sequence;


// Constants defined in the message

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_Result
{
  bool undocked;
} roas_dock__action__Undock_Result;

// Struct for a sequence of roas_dock__action__Undock_Result.
typedef struct roas_dock__action__Undock_Result__Sequence
{
  roas_dock__action__Undock_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose_stamped__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_Feedback
{
  geometry_msgs__msg__PoseStamped pose;
} roas_dock__action__Undock_Feedback;

// Struct for a sequence of roas_dock__action__Undock_Feedback.
typedef struct roas_dock__action__Undock_Feedback__Sequence
{
  roas_dock__action__Undock_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "roas_dock/action/detail/undock__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  roas_dock__action__Undock_Goal goal;
} roas_dock__action__Undock_SendGoal_Request;

// Struct for a sequence of roas_dock__action__Undock_SendGoal_Request.
typedef struct roas_dock__action__Undock_SendGoal_Request__Sequence
{
  roas_dock__action__Undock_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} roas_dock__action__Undock_SendGoal_Response;

// Struct for a sequence of roas_dock__action__Undock_SendGoal_Response.
typedef struct roas_dock__action__Undock_SendGoal_Response__Sequence
{
  roas_dock__action__Undock_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} roas_dock__action__Undock_GetResult_Request;

// Struct for a sequence of roas_dock__action__Undock_GetResult_Request.
typedef struct roas_dock__action__Undock_GetResult_Request__Sequence
{
  roas_dock__action__Undock_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "roas_dock/action/detail/undock__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_GetResult_Response
{
  int8_t status;
  roas_dock__action__Undock_Result result;
} roas_dock__action__Undock_GetResult_Response;

// Struct for a sequence of roas_dock__action__Undock_GetResult_Response.
typedef struct roas_dock__action__Undock_GetResult_Response__Sequence
{
  roas_dock__action__Undock_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "roas_dock/action/detail/undock__struct.h"

// Struct defined in action/Undock in the package roas_dock.
typedef struct roas_dock__action__Undock_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  roas_dock__action__Undock_Feedback feedback;
} roas_dock__action__Undock_FeedbackMessage;

// Struct for a sequence of roas_dock__action__Undock_FeedbackMessage.
typedef struct roas_dock__action__Undock_FeedbackMessage__Sequence
{
  roas_dock__action__Undock_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} roas_dock__action__Undock_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROAS_DOCK__ACTION__DETAIL__UNDOCK__STRUCT_H_
