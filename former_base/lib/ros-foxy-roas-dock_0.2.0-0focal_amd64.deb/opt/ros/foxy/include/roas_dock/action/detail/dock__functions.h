// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from roas_dock:action/Dock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DETAIL__DOCK__FUNCTIONS_H_
#define ROAS_DOCK__ACTION__DETAIL__DOCK__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "roas_dock/msg/rosidl_generator_c__visibility_control.h"

#include "roas_dock/action/detail/dock__struct.h"

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_Goal
 * )) before or use
 * roas_dock__action__Dock_Goal__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Goal__init(roas_dock__action__Dock_Goal * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Goal__fini(roas_dock__action__Dock_Goal * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_Goal__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Goal *
roas_dock__action__Dock_Goal__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_Goal__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Goal__destroy(roas_dock__action__Dock_Goal * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_Goal__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Goal__Sequence__init(roas_dock__action__Dock_Goal__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Goal__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Goal__Sequence__fini(roas_dock__action__Dock_Goal__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_Goal__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Goal__Sequence *
roas_dock__action__Dock_Goal__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Goal__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Goal__Sequence__destroy(roas_dock__action__Dock_Goal__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_Result
 * )) before or use
 * roas_dock__action__Dock_Result__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Result__init(roas_dock__action__Dock_Result * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Result__fini(roas_dock__action__Dock_Result * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_Result__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Result *
roas_dock__action__Dock_Result__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_Result__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Result__destroy(roas_dock__action__Dock_Result * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_Result__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Result__Sequence__init(roas_dock__action__Dock_Result__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Result__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Result__Sequence__fini(roas_dock__action__Dock_Result__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_Result__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Result__Sequence *
roas_dock__action__Dock_Result__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Result__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Result__Sequence__destroy(roas_dock__action__Dock_Result__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_Feedback
 * )) before or use
 * roas_dock__action__Dock_Feedback__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Feedback__init(roas_dock__action__Dock_Feedback * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Feedback__fini(roas_dock__action__Dock_Feedback * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_Feedback__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Feedback *
roas_dock__action__Dock_Feedback__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_Feedback__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Feedback__destroy(roas_dock__action__Dock_Feedback * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_Feedback__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_Feedback__Sequence__init(roas_dock__action__Dock_Feedback__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Feedback__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Feedback__Sequence__fini(roas_dock__action__Dock_Feedback__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_Feedback__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_Feedback__Sequence *
roas_dock__action__Dock_Feedback__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_Feedback__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_Feedback__Sequence__destroy(roas_dock__action__Dock_Feedback__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_SendGoal_Request
 * )) before or use
 * roas_dock__action__Dock_SendGoal_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_SendGoal_Request__init(roas_dock__action__Dock_SendGoal_Request * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Request__fini(roas_dock__action__Dock_SendGoal_Request * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_SendGoal_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_SendGoal_Request *
roas_dock__action__Dock_SendGoal_Request__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Request__destroy(roas_dock__action__Dock_SendGoal_Request * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_SendGoal_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_SendGoal_Request__Sequence__init(roas_dock__action__Dock_SendGoal_Request__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Request__Sequence__fini(roas_dock__action__Dock_SendGoal_Request__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_SendGoal_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_SendGoal_Request__Sequence *
roas_dock__action__Dock_SendGoal_Request__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Request__Sequence__destroy(roas_dock__action__Dock_SendGoal_Request__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_SendGoal_Response
 * )) before or use
 * roas_dock__action__Dock_SendGoal_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_SendGoal_Response__init(roas_dock__action__Dock_SendGoal_Response * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Response__fini(roas_dock__action__Dock_SendGoal_Response * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_SendGoal_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_SendGoal_Response *
roas_dock__action__Dock_SendGoal_Response__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Response__destroy(roas_dock__action__Dock_SendGoal_Response * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_SendGoal_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_SendGoal_Response__Sequence__init(roas_dock__action__Dock_SendGoal_Response__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Response__Sequence__fini(roas_dock__action__Dock_SendGoal_Response__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_SendGoal_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_SendGoal_Response__Sequence *
roas_dock__action__Dock_SendGoal_Response__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_SendGoal_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_SendGoal_Response__Sequence__destroy(roas_dock__action__Dock_SendGoal_Response__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_GetResult_Request
 * )) before or use
 * roas_dock__action__Dock_GetResult_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_GetResult_Request__init(roas_dock__action__Dock_GetResult_Request * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Request__fini(roas_dock__action__Dock_GetResult_Request * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_GetResult_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_GetResult_Request *
roas_dock__action__Dock_GetResult_Request__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Request__destroy(roas_dock__action__Dock_GetResult_Request * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_GetResult_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_GetResult_Request__Sequence__init(roas_dock__action__Dock_GetResult_Request__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Request__Sequence__fini(roas_dock__action__Dock_GetResult_Request__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_GetResult_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_GetResult_Request__Sequence *
roas_dock__action__Dock_GetResult_Request__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Request__Sequence__destroy(roas_dock__action__Dock_GetResult_Request__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_GetResult_Response
 * )) before or use
 * roas_dock__action__Dock_GetResult_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_GetResult_Response__init(roas_dock__action__Dock_GetResult_Response * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Response__fini(roas_dock__action__Dock_GetResult_Response * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_GetResult_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_GetResult_Response *
roas_dock__action__Dock_GetResult_Response__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Response__destroy(roas_dock__action__Dock_GetResult_Response * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_GetResult_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_GetResult_Response__Sequence__init(roas_dock__action__Dock_GetResult_Response__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Response__Sequence__fini(roas_dock__action__Dock_GetResult_Response__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_GetResult_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_GetResult_Response__Sequence *
roas_dock__action__Dock_GetResult_Response__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_GetResult_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_GetResult_Response__Sequence__destroy(roas_dock__action__Dock_GetResult_Response__Sequence * array);

/// Initialize action/Dock message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * roas_dock__action__Dock_FeedbackMessage
 * )) before or use
 * roas_dock__action__Dock_FeedbackMessage__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_FeedbackMessage__init(roas_dock__action__Dock_FeedbackMessage * msg);

/// Finalize action/Dock message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_FeedbackMessage__fini(roas_dock__action__Dock_FeedbackMessage * msg);

/// Create action/Dock message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * roas_dock__action__Dock_FeedbackMessage__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_FeedbackMessage *
roas_dock__action__Dock_FeedbackMessage__create();

/// Destroy action/Dock message.
/**
 * It calls
 * roas_dock__action__Dock_FeedbackMessage__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_FeedbackMessage__destroy(roas_dock__action__Dock_FeedbackMessage * msg);


/// Initialize array of action/Dock messages.
/**
 * It allocates the memory for the number of elements and calls
 * roas_dock__action__Dock_FeedbackMessage__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
bool
roas_dock__action__Dock_FeedbackMessage__Sequence__init(roas_dock__action__Dock_FeedbackMessage__Sequence * array, size_t size);

/// Finalize array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_FeedbackMessage__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_FeedbackMessage__Sequence__fini(roas_dock__action__Dock_FeedbackMessage__Sequence * array);

/// Create array of action/Dock messages.
/**
 * It allocates the memory for the array and calls
 * roas_dock__action__Dock_FeedbackMessage__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
roas_dock__action__Dock_FeedbackMessage__Sequence *
roas_dock__action__Dock_FeedbackMessage__Sequence__create(size_t size);

/// Destroy array of action/Dock messages.
/**
 * It calls
 * roas_dock__action__Dock_FeedbackMessage__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_roas_dock
void
roas_dock__action__Dock_FeedbackMessage__Sequence__destroy(roas_dock__action__Dock_FeedbackMessage__Sequence * array);

#ifdef __cplusplus
}
#endif

#endif  // ROAS_DOCK__ACTION__DETAIL__DOCK__FUNCTIONS_H_
