// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from roas_dock:action/Undock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DETAIL__UNDOCK__TRAITS_HPP_
#define ROAS_DOCK__ACTION__DETAIL__UNDOCK__TRAITS_HPP_

#include "roas_dock/action/detail/undock__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_Goal>()
{
  return "roas_dock::action::Undock_Goal";
}

template<>
inline const char * name<roas_dock::action::Undock_Goal>()
{
  return "roas_dock/action/Undock_Goal";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_Goal>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_Goal>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<roas_dock::action::Undock_Goal>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_Result>()
{
  return "roas_dock::action::Undock_Result";
}

template<>
inline const char * name<roas_dock::action::Undock_Result>()
{
  return "roas_dock/action/Undock_Result";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_Result>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_Result>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<roas_dock::action::Undock_Result>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose_stamped__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_Feedback>()
{
  return "roas_dock::action::Undock_Feedback";
}

template<>
inline const char * name<roas_dock::action::Undock_Feedback>()
{
  return "roas_dock/action/Undock_Feedback";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_Feedback>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::PoseStamped>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_Feedback>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::PoseStamped>::value> {};

template<>
struct is_message<roas_dock::action::Undock_Feedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'goal'
#include "roas_dock/action/detail/undock__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_SendGoal_Request>()
{
  return "roas_dock::action::Undock_SendGoal_Request";
}

template<>
inline const char * name<roas_dock::action::Undock_SendGoal_Request>()
{
  return "roas_dock/action/Undock_SendGoal_Request";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_SendGoal_Request>
  : std::integral_constant<bool, has_fixed_size<roas_dock::action::Undock_Goal>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_SendGoal_Request>
  : std::integral_constant<bool, has_bounded_size<roas_dock::action::Undock_Goal>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<roas_dock::action::Undock_SendGoal_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_SendGoal_Response>()
{
  return "roas_dock::action::Undock_SendGoal_Response";
}

template<>
inline const char * name<roas_dock::action::Undock_SendGoal_Response>()
{
  return "roas_dock/action/Undock_SendGoal_Response";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_SendGoal_Response>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_SendGoal_Response>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<roas_dock::action::Undock_SendGoal_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_SendGoal>()
{
  return "roas_dock::action::Undock_SendGoal";
}

template<>
inline const char * name<roas_dock::action::Undock_SendGoal>()
{
  return "roas_dock/action/Undock_SendGoal";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_SendGoal>
  : std::integral_constant<
    bool,
    has_fixed_size<roas_dock::action::Undock_SendGoal_Request>::value &&
    has_fixed_size<roas_dock::action::Undock_SendGoal_Response>::value
  >
{
};

template<>
struct has_bounded_size<roas_dock::action::Undock_SendGoal>
  : std::integral_constant<
    bool,
    has_bounded_size<roas_dock::action::Undock_SendGoal_Request>::value &&
    has_bounded_size<roas_dock::action::Undock_SendGoal_Response>::value
  >
{
};

template<>
struct is_service<roas_dock::action::Undock_SendGoal>
  : std::true_type
{
};

template<>
struct is_service_request<roas_dock::action::Undock_SendGoal_Request>
  : std::true_type
{
};

template<>
struct is_service_response<roas_dock::action::Undock_SendGoal_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_GetResult_Request>()
{
  return "roas_dock::action::Undock_GetResult_Request";
}

template<>
inline const char * name<roas_dock::action::Undock_GetResult_Request>()
{
  return "roas_dock/action/Undock_GetResult_Request";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_GetResult_Request>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_GetResult_Request>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<roas_dock::action::Undock_GetResult_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'result'
// already included above
// #include "roas_dock/action/detail/undock__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_GetResult_Response>()
{
  return "roas_dock::action::Undock_GetResult_Response";
}

template<>
inline const char * name<roas_dock::action::Undock_GetResult_Response>()
{
  return "roas_dock/action/Undock_GetResult_Response";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_GetResult_Response>
  : std::integral_constant<bool, has_fixed_size<roas_dock::action::Undock_Result>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_GetResult_Response>
  : std::integral_constant<bool, has_bounded_size<roas_dock::action::Undock_Result>::value> {};

template<>
struct is_message<roas_dock::action::Undock_GetResult_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_GetResult>()
{
  return "roas_dock::action::Undock_GetResult";
}

template<>
inline const char * name<roas_dock::action::Undock_GetResult>()
{
  return "roas_dock/action/Undock_GetResult";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_GetResult>
  : std::integral_constant<
    bool,
    has_fixed_size<roas_dock::action::Undock_GetResult_Request>::value &&
    has_fixed_size<roas_dock::action::Undock_GetResult_Response>::value
  >
{
};

template<>
struct has_bounded_size<roas_dock::action::Undock_GetResult>
  : std::integral_constant<
    bool,
    has_bounded_size<roas_dock::action::Undock_GetResult_Request>::value &&
    has_bounded_size<roas_dock::action::Undock_GetResult_Response>::value
  >
{
};

template<>
struct is_service<roas_dock::action::Undock_GetResult>
  : std::true_type
{
};

template<>
struct is_service_request<roas_dock::action::Undock_GetResult_Request>
  : std::true_type
{
};

template<>
struct is_service_response<roas_dock::action::Undock_GetResult_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'feedback'
// already included above
// #include "roas_dock/action/detail/undock__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<roas_dock::action::Undock_FeedbackMessage>()
{
  return "roas_dock::action::Undock_FeedbackMessage";
}

template<>
inline const char * name<roas_dock::action::Undock_FeedbackMessage>()
{
  return "roas_dock/action/Undock_FeedbackMessage";
}

template<>
struct has_fixed_size<roas_dock::action::Undock_FeedbackMessage>
  : std::integral_constant<bool, has_fixed_size<roas_dock::action::Undock_Feedback>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<roas_dock::action::Undock_FeedbackMessage>
  : std::integral_constant<bool, has_bounded_size<roas_dock::action::Undock_Feedback>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<roas_dock::action::Undock_FeedbackMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits


namespace rosidl_generator_traits
{

template<>
struct is_action<roas_dock::action::Undock>
  : std::true_type
{
};

template<>
struct is_action_goal<roas_dock::action::Undock_Goal>
  : std::true_type
{
};

template<>
struct is_action_result<roas_dock::action::Undock_Result>
  : std::true_type
{
};

template<>
struct is_action_feedback<roas_dock::action::Undock_Feedback>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits


#endif  // ROAS_DOCK__ACTION__DETAIL__UNDOCK__TRAITS_HPP_
