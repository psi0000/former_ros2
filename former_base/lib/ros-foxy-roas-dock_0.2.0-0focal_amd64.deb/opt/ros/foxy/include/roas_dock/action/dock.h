// generated from rosidl_generator_c/resource/idl.h.em
// with input from roas_dock:action/Dock.idl
// generated code does not contain a copyright notice

#ifndef ROAS_DOCK__ACTION__DOCK_H_
#define ROAS_DOCK__ACTION__DOCK_H_

#include "roas_dock/action/detail/dock__struct.h"
#include "roas_dock/action/detail/dock__functions.h"
#include "roas_dock/action/detail/dock__type_support.h"

#endif  // ROAS_DOCK__ACTION__DOCK_H_
